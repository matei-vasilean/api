// backend/utils/avgRating.js
exports.calculateAverageRating = async (rating) => {
    if (!rating || rating.length === 0) {
      return { averageRating: 0, nrReviews: 0 };
    }
  
    const totalRating = rating.reduce((sum, report) => sum + report.rating, 0);
    const avgRating = totalRating / rating.length;
  
    return { averageRating: avgRating.toFixed(1), nrReviews: rating.length };
};