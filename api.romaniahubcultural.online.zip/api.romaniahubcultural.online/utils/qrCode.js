// backend/utils/qrCode.js
exports.generateQRCode = async (sessionId) => {
    try {
        const qrCodeText = `QR-${sessionId}-${Math.floor(Math.random() * 10000)}`;
        return qrCodeText;
    } catch (error) {
        console.error('Error generating QR code:', error);
        throw error;
    }
};