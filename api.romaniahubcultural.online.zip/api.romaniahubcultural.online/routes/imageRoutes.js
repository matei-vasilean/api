//routes/imageRoutes.js
const express = require('express');
const upload = require('../middlewares/upload');
const Location = require('../models/Location');
const router = express.Router();

router.get('/getImages/:locationId', async (req, res) => {
    const { locationId } = req.params;

    try {
        const location = await Location.findById(locationId);
        if (!location) {
            return res.status(404).json({ message: 'Location not found' });
        }

        res.status(200).json(location.imagePaths.map(filePath => ({ filePath })));
    } catch (error) {
        console.error('Error fetching location images:', error);
        res.status(500).json({ message: 'Failed to fetch location images' });
    }
});

router.post('/upload/:locationId', (req, res) => {
    upload(req, res, async (err) => {
        if (err) {
            return res.status(400).json({ message: err });
        }
        if (req.file === undefined) {
            return res.status(400).json({ message: 'No file selected' });
        }
        const locationId = req.params.locationId;

        try {
            const location = await Location.findById(locationId);
            if (!location) {
                return res.status(404).json({ message: 'Location not found' });
            }

            location.imagePaths.push(`/uploads/${req.file.filename}`);
            await location.save();

            res.status(200).json({
                message: 'File uploaded successfully',
                filePath: `/uploads/${req.file.filename}`,
                locationId: locationId
            });
        } catch (error) {
            console.error('Error saving image path:', error);
            res.status(500).json({ message: 'Failed to save image path' });
        }
    });
});

module.exports = router;