//routes/notificationRoutes.js
const express = require('express');
const { addNotification, getNotifications } = require('../controllers/notificationController');
const router = express.Router();

router.post('/addNotification', addNotification);
router.get('/getNotifications', getNotifications);

module.exports = router;