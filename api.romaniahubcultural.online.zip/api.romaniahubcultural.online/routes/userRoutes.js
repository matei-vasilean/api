//routes/userRoutes.js
const express = require('express');
const { login, register, getProfile, deleteUser, logout, checkLogin, editProfile, changePassword, getAllUsers, getUserProfile, addToWishlist, removeFromWishlist, addToVisited,
    removeFromVisited, addToLoved, removeFromLoved, sendFriendRequest, acceptFriendRequest, rejectFriendRequest, removeFriend } = require('../controllers/userController');
const requireAuth = require('../middlewares/auth');
const router = express.Router();

router.get('/getProfile', requireAuth, getProfile);
router.get('/getAllUsers', getAllUsers);
router.post('/login', login);
router.post('/register', register);
router.post('/logout', requireAuth, logout);
router.get('/checkLogin', checkLogin);
router.post('/editProfile', requireAuth, editProfile);
router.post('/changePassword', requireAuth, changePassword);
router.delete('/deleteUser', requireAuth, deleteUser);
router.get('/:userId', getUserProfile);
router.post('/:userId/addToWishlist', addToWishlist);
router.post('/:userId/removeFromWishlist', removeFromWishlist);
router.post('/:userId/addToVisited', addToVisited);
router.post('/:userId/removeFromVisited', removeFromVisited);
router.post('/:userId/addToLoved', addToLoved);
router.post('/:userId/removeFromLoved', removeFromLoved);
router.post('/:userId/sendFriendRequest', sendFriendRequest);
router.post('/:userId/acceptFriendRequest', acceptFriendRequest);
router.post('/:userId/rejectFriendRequest', rejectFriendRequest);
router.post('/:userId/removeFriend', removeFriend);

module.exports = router;