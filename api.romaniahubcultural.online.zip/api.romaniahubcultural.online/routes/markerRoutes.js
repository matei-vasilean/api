//routes/markerRoutes.js
const express = require('express');
const { getMarkers } = require('../controllers/markerController');
const router = express.Router();

router.get('/getMarkers', getMarkers);

module.exports = router;