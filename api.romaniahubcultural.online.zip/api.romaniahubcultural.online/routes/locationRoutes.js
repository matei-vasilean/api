//routes/locationRoutes.js
const express = require('express');
const { getLocation, getPendingLocation, submitLocation, approvePendingLocation, searchLocations } = require('../controllers/locationController');
const requireAuth = require('../middlewares/auth');
const router = express.Router();

router.get('/locations/:locationId', getLocation);
router.get('/getPendingLocation', getPendingLocation);
router.post('/submitLocation', requireAuth, submitLocation);
router.post('/approvePendingLocation/:locationId', approvePendingLocation);
router.get('/search', searchLocations);

module.exports = router;