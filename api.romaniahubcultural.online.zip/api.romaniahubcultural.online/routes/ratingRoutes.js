//routes/ratingRoutes.js
const express = require('express');
const { getRating, submitRating, getReviews } = require('../controllers/ratingController');
const requireAuth = require('../middlewares/auth');
const router = express.Router();

router.get('/getRating', getRating);
router.post('/submitRating', requireAuth, submitRating);
router.get('/:locationId/reviews', getReviews);

module.exports = router;