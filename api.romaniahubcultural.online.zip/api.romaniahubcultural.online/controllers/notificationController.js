//controllers/notificationController.js
const notifications = [];

exports.addNotification = (message) => {
    notifications.push({ message, timestamp: new Date() });
};

exports.getNotifications = async (req, res) => {
    const { lastFetched } = req.query;
    const newNotifications = lastFetched
        ? notifications.filter(n => new Date(n.timestamp) > new Date(lastFetched))
        : notifications;
    res.status(200).json(newNotifications);
};