//controllers/ratingController.js
const upload = require('../middlewares/upload');
const Rating = require('../models/Rating');
const Location = require('../models/Location');

exports.getRating = async (req, res) => {
  try {
    const ratings = await Rating.find();
    res.json(ratings);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.submitRating = [upload.single('photoUrl'), async (req, res) => {
  try {
    console.log('Incoming request body:', req.body);
    console.log('Incoming file:', req.file);

    const { rating, text, locationId } = req.body;
    
    if (!rating || !text || !locationId) {
      return res.status(400).json({ message: 'Missing required fields' });
    }

    const userId = req.userId;
    const newRating = new Rating({
      rating,
      text,
      photoUrl: req.file ? `/uploads/${req.file.filename}` : null,
      locationId,
      timestamp: new Date(),
      userId,
    });

    await newRating.save();

    const ratings = await Rating.find({ locationId });
    const { averageRating, nrReviews } = calculateAverageRating(ratings);

    const location = await Location.findById(locationId);
    location.averageRating = averageRating;
    location.nrReviews = nrReviews;
    await location.save();

    res.status(201).json(newRating);
  } catch (err) {
    console.error('Error in submitRating:', err);
    res.status(500).json({ message: err.message });
  }
}];

exports.getReviews = async (req, res) => {
  try {
    const { locationId } = req.params;
    const reviews = await Rating.find({ locationId }).sort({ timestamp: -1 });
    res.json(reviews);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

const calculateAverageRating = (ratings) => {
  if (!ratings || ratings.length === 0) return { averageRating: 0, nrReviews: 0 };
  const totalRating = ratings.reduce((sum, rating) => sum + rating.rating, 0);
  const avgRating = totalRating / ratings.length;
  return { averageRating: avgRating.toFixed(1), nrReviews: ratings.length };
};