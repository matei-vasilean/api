//controllers/userController.js
const User = require('../models/User');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
//move it to env
const JWT_SECRET = 'eyJhbGciOiJIUzI1NiJ9.eyJSb2xlIjoiQWRtaW4iLCJJc3N1ZXIiOiJJc3N1ZXIiLCJVc2VybmFtZSI6IkphdmFJblVzZSIsImV4cCI6MTcxOTMxODM0OSwiaWF0IjoxNzE5MzE4MzQ5fQ.bdDTUZ9G72cWEnen0nlE4oON2RkjRy-ZR5OQIvB_JVA';

exports.register = async (req, res) => {
  try {
    const { username, email, password } = req.body;
    const existingUser = await User.findOne({ username });
    if (existingUser) {
      return res.status(400).json({ message: 'Username already exists' });
    }
    const hashedPassword = await bcrypt.hash(password, 10);
    const user = new User({ username, email, password: hashedPassword });
    await user.save();
    const token = jwt.sign({ userId: user._id }, JWT_SECRET, { expiresIn: '30d' });
    res.status(201).json({ token, message: 'User registered successfully' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.login = async (req, res) => {
  try {
    const { usernameOrEmail, password } = req.body;
    const user = await User.findOne({
      $or: [
        { username: usernameOrEmail },
        { email: usernameOrEmail }
      ]
    });

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return res.status(401).json({ message: 'Invalid password' });
    }

    const token = jwt.sign({ userId: user._id }, JWT_SECRET, { expiresIn: '30d' });
    res.status(200).json({ token, userId: user._id, message: 'Login successful' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.deleteUser = async (req, res) => {
  try {
    const userId = req.userId;

    const deletedUser = await User.findByIdAndDelete(userId);
    if (!deletedUser) {
      return res.status(404).json({ message: 'User not found' });
    }
    res.status(200).json({ message: 'User deleted successfully' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
  
exports.logout = async (res) => {
  res.status(200).json({ message: 'Logout successful' });
};
  
exports.checkLogin = async (res) => {
  res.status(200).json({ loggedIn: true });
};

exports.getProfile = async (req, res) => {
  try {
    const user = await User.findById(req.userId)
      .select('username email friends')
      .populate('friends', 'username')
      .populate('friendRequests', 'username')
      .populate('wishlist', 'name')
      .populate('visited', 'name')
      .populate('loved', 'name');

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.status(200).json(user);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.getUserProfile = async (req, res) => {
  try {
      const user = await User.findById(req.params.userId)
          .populate('friends', 'username')
          .populate('wishlist', 'name')
          .populate('visited', 'name')
          .populate('loved', 'name');
      res.json(user);
  } catch (error) {
      res.status(500).json({ error: 'Failed to get user profile' });
  }
};

exports.getAllUsers = async (req, res) => {
  try {
    const users = await User.find().select('username email');
    res.status(200).json(users);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
  
exports.editProfile = async (req, res) => {
  try {
    const { username, email } = req.body;
    const userId = req.userId;

    const updatedUser = await User.findByIdAndUpdate(userId, { username, email }, { new: true });

    if (!updatedUser) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.status(200).json(updatedUser);
  } catch (error) {
    console.error('Error updating profile:', error);
    res.status(500).json({ message: 'Failed to update profile. Please try again later.' });
  }
};
  
exports.changePassword = async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    const userId = req.userId;

    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const isPasswordValid = await bcrypt.compare(currentPassword, user.password);

    if (!isPasswordValid) {
      return res.status(401).json({ message: 'Current password is incorrect' });
    }

    const hashedPassword = await bcrypt.hash(newPassword, 10);
    user.password = hashedPassword;
    await user.save();

    res.status(200).json({ message: 'Password changed successfully' });
  } catch (error) {
    console.error('Error changing password:', error);
    res.status(500).json({ message: 'Failed to change password. Please try again later.' });
  }
};

exports.addToWishlist = async (req, res) => {
  const { locationId } = req.body;
  try {
    await User.findByIdAndUpdate(
      req.params.userId,
      {
        $addToSet: { wishlist: locationId },
        $pull: { visited: locationId },
      }
    );
    res.json({ message: 'Location added to wishlist and removed from visited if present' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to add to wishlist' });
  }
};

exports.removeFromWishlist = async (req, res) => {
  const { locationId } = req.body;
  try {
    await User.findByIdAndUpdate(req.params.userId, { $pull: { wishlist: locationId } });
    res.json({ message: 'Location removed from wishlist' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to remove from wishlist' });
  }
};

exports.addToVisited = async (req, res) => {
  const { locationId } = req.body;
  try {
    await User.findByIdAndUpdate(
      req.params.userId,
      {
        $addToSet: { visited: locationId },
        $pull: { wishlist: locationId },
      }
    );
    res.json({ message: 'Location added to visited list and removed from wishlist if present' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to add to visited list' });
  }
};

exports.removeFromVisited = async (req, res) => {
  const { locationId } = req.body;
  try {
    await User.findByIdAndUpdate(req.params.userId, { $pull: { visited: locationId } });
    res.json({ message: 'Location removed from visited list' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to remove from visited list' });
  }
};

exports.addToLoved = async (req, res) => {
  const { locationId } = req.body;
  try {
      await User.findByIdAndUpdate(req.params.userId, { $addToSet: { loved: locationId } });
      res.json({ message: 'Location added to loved list' });
  } catch (error) {
      res.status(500).json({ error: 'Failed to add to loved list' });
  }
};

exports.removeFromLoved = async (req, res) => {
  const { locationId } = req.body;
  try {
      await User.findByIdAndUpdate(req.params.userId, { $pull: { loved: locationId } });
      res.json({ message: 'Location removed from loved list' });
  } catch (error) {
      res.status(500).json({ error: 'Failed to remove from loved list' });
  }
};

exports.sendFriendRequest = async (req, res) => {
  const { userId } = req.body;

  try {
    const user = await User.findById(req.params.userId);
    if (user.friends.includes(userId)) {
      return res.status(400).json({ error: 'Already friends with this user' });
    }

    await User.findByIdAndUpdate(userId, { $addToSet: { friendRequests: req.params.userId } });
    res.json({ message: 'Friend request sent' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to send friend request' });
  }
};

exports.acceptFriendRequest = async (req, res) => {
  const { userId } = req.body;

  try {
    await User.findByIdAndUpdate(req.params.userId, {
      $addToSet: { friends: userId },
      $pull: { friendRequests: userId },
    });

    await User.findByIdAndUpdate(userId, {
      $addToSet: { friends: req.params.userId },
      $pull: { friendRequests: req.params.userId },
    });

    res.json({ message: 'Friend request accepted' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to accept friend request' });
  }
};

exports.rejectFriendRequest = async (req, res) => {
  const { userId } = req.body;

  try {
    await User.findByIdAndUpdate(req.params.userId, {
      $pull: { friendRequests: userId },
    });

    res.json({ message: 'Friend request rejected' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to reject friend request' });
  }
};

exports.removeFriend = async (req, res) => {
  const { friendId } = req.body;
  try {
      await User.findByIdAndUpdate(req.params.userId, { $pull: { friends: friendId } });
      await User.findByIdAndUpdate(friendId, { $pull: { friends: req.params.userId } });
      res.json({ message: 'Friend removed' });
  } catch (error) {
      res.status(500).json({ error: 'Failed to remove friend' });
  }
};