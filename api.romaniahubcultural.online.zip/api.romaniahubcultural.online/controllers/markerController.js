//controllers/markerController.js
const Marker = require('../models/Marker');

exports.getMarkers = async (req, res) => {
  try {
    const markers = await Marker.find();
    if (!markers || markers.length === 0) {
      return res.status(404).json({ message: 'No markers found' });
    }
    res.json(markers);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};