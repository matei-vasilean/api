//controllers/tourController.js
const Tour = require('../models/Tour');

exports.getTours = async (req, res) => {
  try {
    const tours = await Tour.find();
    if (!tours || tours.length === 0) {
      return res.status(404).json({ message: 'No tours found' });
    }
    res.json(tours);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};