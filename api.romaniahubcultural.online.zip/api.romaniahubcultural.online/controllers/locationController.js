//controllers/locationController.js
const Location = require('../models/Location');
const PendingLocation = require('../models/PendingLocation');

exports.getLocation = async (req, res) => {
  try {
    const locationId = req.params.locationId;
    const location = await Location.findById(locationId);
    if (!location) {
      return res.status(404).json({ message: 'Location not found' });
    }
    res.json(location);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.submitLocation = async (req, res) => {
  try {
    const { description, latitude, longitude, name } = req.body;
    const submittedBy = req.userId;

    const newPendingLocation = new PendingLocation({
      name,
      description,
      latitude,
      longitude,
      submittedBy
    });

    await newPendingLocation.save();
    res.status(201).json({ message: 'Location request submitted successfully' });
  } catch (err) {
    console.error('Submit Location Request Error:', err);
    res.status(500).json({ message: err.message });
  }
};

exports.getPendingLocation = async (req, res) => {
  try {
    const pendingLocations = await PendingLocation.find({ isApproved: 'pending' });
    res.status(200).json(pendingLocations);
  } catch (err) {
    console.error('Error fetching pending locations:', err);
    res.status(500).json({ message: 'Failed to fetch pending locations' });
  }
};

exports.approvePendingLocation = async (req, res) => {
  try {
    const { locationId } = req.params;
    const { action, rejectedReason } = req.body;

    const pendingLocation = await PendingLocation.findById(locationId);
    if (!pendingLocation) {
      return res.status(404).json({ message: 'Pending location not found' });
    }

    if (action === 'approve') {
      const newLocation = new Location({
        name: pendingLocation.name,
        description: pendingLocation.description,
        latitude: pendingLocation.latitude,
        longitude: pendingLocation.longitude,
        averageRating: 0,
        nrReviews: 0,
      });

      await newLocation.save();

      pendingLocation.isApproved = 'approved';
      await pendingLocation.save();

      res.status(201).json({ message: 'Location approved and added to database' });
    } else if (action === 'reject') {
      pendingLocation.isApproved = 'rejected';
      pendingLocation.rejectedReason = rejectedReason;
      await pendingLocation.save();

      res.status(200).json({ message: 'Location request rejected' });
    } else {
      return res.status(400).json({ message: 'Invalid action' });
    }
  } catch (err) {
    console.error('Approve/Reject Location Error:', err);
    res.status(500).json({ message: err.message });
  }
};

exports.searchLocations = async (req, res) => {
  try {
    const { q } = req.query;

    if (q) {
      const locations = await Location.aggregate([
      {
        $search: {
          index: "name",
          text: {
            query: q,
            path: "name",
            fuzzy: {
              maxEdits: 2
            }
          }
        }
      }
    ]);

      res.json({ locations });
    } else {
      const locations = await Location.find({});
      res.json({ locations });
    }
  } catch (error) {
    console.error('Error fetching search results:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};