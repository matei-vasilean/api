//server.js
const express = require('express');
const cors = require('cors');
const path = require('path');
const connectDB = require('./config/db');
const userRoutes = require('./routes/userRoutes');
const markerRoutes = require('./routes/markerRoutes');
const locationRoutes = require('./routes/locationRoutes');
const tourRoutes = require('./routes/tourRoutes');
const notificationRoutes = require('./routes/notificationRoutes');
const ratingRoutes = require('./routes/ratingRoutes');
const imageRoutes = require('./routes/imageRoutes');

const app = express();
const port = 3000;

app.use(express.json());
app.use(cors());

connectDB();

app.use('/api/users', userRoutes);
app.use('/api/markers', markerRoutes);
app.use('/api/locations', locationRoutes);
app.use('/api/tours', tourRoutes);
app.use('/api/ratings', ratingRoutes);
app.use('/api/images', imageRoutes);
app.use('/notifications', notificationRoutes);
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

app.listen(port, '0.0.0.0', () => {
    console.log(`Server is running`);
});