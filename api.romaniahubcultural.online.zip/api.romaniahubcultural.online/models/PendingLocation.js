//models/PendingLocation.js
const mongoose = require('mongoose');

const pendingLocationSchema = new mongoose.Schema({
    name: String,
    description: String,
    latitude: Number,
    longitude: Number,
    submittedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    createdAt: { type: Date, default: Date.now },
    isApproved: { type: String, enum: ['pending', 'approved', 'rejected'], default: 'pending' },
    rejectedReason: String
  });

module.exports = mongoose.model('pendingLocation', pendingLocationSchema);