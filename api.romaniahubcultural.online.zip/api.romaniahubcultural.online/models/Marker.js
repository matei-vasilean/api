//models/Marker.js
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const markerSchema = new mongoose.Schema({
    _id: Schema.Types.ObjectId,
    latitude: Number,
    longitude: Number,
    type: String,
});

module.exports = mongoose.model('Marker', markerSchema);