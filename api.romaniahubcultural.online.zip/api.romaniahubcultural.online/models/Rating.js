//models/Rating.js
const mongoose = require('mongoose');

const ratingSchema = new mongoose.Schema({
  rating: Number,
  text: String,
  photoUrl: String,
  locationId: { type: mongoose.Schema.Types.ObjectId, ref: 'Location' },
  timestamp: { type: Date, default: Date.now },
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
});

module.exports = mongoose.model('Rating', ratingSchema);