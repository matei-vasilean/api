// backend/middlewares/auth.js
const jwt = require('jsonwebtoken');
const JWT_SECRET = 'eyJhbGciOiJIUzI1NiJ9.eyJSb2xlIjoiQWRtaW4iLCJJc3N1ZXIiOiJJc3N1ZXIiLCJVc2VybmFtZSI6IkphdmFJblVzZSIsImV4cCI6MTcxOTMxODM0OSwiaWF0IjoxNzE5MzE4MzQ5fQ.bdDTUZ9G72cWEnen0nlE4oON2RkjRy-ZR5OQIvB_JVA';

const requireAuth = (req, res, next) => {
    const token = req.headers.authorization && req.headers.authorization.split(' ')[1];
    if (!token) {
        return res.status(401).json({ message: 'Unauthorized' });
    }

    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        req.userId = decoded.userId;
        next();
    } catch (err) {
        console.error('JWT Verification Error:', err);
        res.status(401).json({ message: 'Unauthorized' });
    }
};

module.exports = requireAuth;